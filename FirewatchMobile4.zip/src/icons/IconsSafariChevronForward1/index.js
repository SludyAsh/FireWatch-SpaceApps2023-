export { IconsSafariChevronForward1 } from "./IconsSafariChevronForward1";
