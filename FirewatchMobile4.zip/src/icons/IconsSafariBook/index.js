export { IconsSafariBook } from "./IconsSafariBook";
