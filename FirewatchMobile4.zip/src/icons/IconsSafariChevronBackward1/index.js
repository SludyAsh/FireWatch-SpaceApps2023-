export { IconsSafariChevronBackward1 } from "./IconsSafariChevronBackward1";
