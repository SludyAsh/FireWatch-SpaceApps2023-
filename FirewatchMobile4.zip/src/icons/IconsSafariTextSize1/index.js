export { IconsSafariTextSize1 } from "./IconsSafariTextSize1";
