export { IconsSafariBook1 } from "./IconsSafariBook1";
