export { IconsSafariWindows1 } from "./IconsSafariWindows1";
