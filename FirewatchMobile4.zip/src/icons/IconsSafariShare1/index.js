export { IconsSafariShare1 } from "./IconsSafariShare1";
