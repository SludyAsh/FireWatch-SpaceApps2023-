export { IconsSafariLock3 } from "./IconsSafariLock3";
