export { IconsPin2 } from "./IconsPin2";
