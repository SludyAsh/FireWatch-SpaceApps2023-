export { IconsSafariRefresh2 } from "./IconsSafariRefresh2";
