import { InterfaceSearch } from ".";

export default {
  title: "Components/InterfaceSearch",
  component: InterfaceSearch,
};

export const Default = {
  args: {},
};
