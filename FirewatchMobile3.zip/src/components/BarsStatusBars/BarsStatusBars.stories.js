import { BarsStatusBars } from ".";

export default {
  title: "Components/BarsStatusBars",
  component: BarsStatusBars,
};

export const Default = {
  args: {
    className: {},
    timeClassName: {},
    text: "09:41",
  },
};
