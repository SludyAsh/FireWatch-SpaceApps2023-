export { IconsPin } from "./IconsPin";
