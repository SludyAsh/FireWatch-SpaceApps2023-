export { ArrowArrowCircleRight } from "./ArrowArrowCircleRight";
