export { IconsSafariTextSize3 } from "./IconsSafariTextSize3";
