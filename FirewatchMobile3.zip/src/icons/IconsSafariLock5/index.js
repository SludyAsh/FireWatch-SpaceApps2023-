export { IconsSafariLock5 } from "./IconsSafariLock5";
