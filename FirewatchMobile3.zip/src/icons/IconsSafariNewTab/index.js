export { IconsSafariNewTab } from "./IconsSafariNewTab";
