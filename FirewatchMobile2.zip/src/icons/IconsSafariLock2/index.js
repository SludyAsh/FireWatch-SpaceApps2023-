export { IconsSafariLock2 } from "./IconsSafariLock2";
