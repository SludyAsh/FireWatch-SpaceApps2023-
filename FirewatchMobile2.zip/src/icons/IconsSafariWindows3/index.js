export { IconsSafariWindows3 } from "./IconsSafariWindows3";
