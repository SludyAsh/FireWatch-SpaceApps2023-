export { IconsSafariShare3 } from "./IconsSafariShare3";
