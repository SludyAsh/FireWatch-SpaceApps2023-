export { IconsSafariBook3 } from "./IconsSafariBook3";
