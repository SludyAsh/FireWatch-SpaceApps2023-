export { TechMessagingXWrapper } from "./TechMessagingXWrapper";
