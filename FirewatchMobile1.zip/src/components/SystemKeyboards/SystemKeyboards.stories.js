import { SystemKeyboards } from ".";

export default {
  title: "Components/SystemKeyboards",
  component: SystemKeyboards,
};

export const Default = {
  args: {
    className: {},
    backgroundClassName: {},
  },
};
