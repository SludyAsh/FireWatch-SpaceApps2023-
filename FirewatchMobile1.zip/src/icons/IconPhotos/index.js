export { IconPhotos } from "./IconPhotos";
