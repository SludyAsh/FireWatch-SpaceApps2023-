export { IconAnimoji1 } from "./IconAnimoji1";
