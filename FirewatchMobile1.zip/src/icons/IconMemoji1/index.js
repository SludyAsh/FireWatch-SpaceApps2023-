export { IconMemoji1 } from "./IconMemoji1";
