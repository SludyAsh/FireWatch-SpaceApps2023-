export { IconDigitalTouch } from "./IconDigitalTouch";
