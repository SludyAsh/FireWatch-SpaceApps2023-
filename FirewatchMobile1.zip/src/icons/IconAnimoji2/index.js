export { IconAnimoji2 } from "./IconAnimoji2";
