export { IconAnimoji } from "./IconAnimoji";
