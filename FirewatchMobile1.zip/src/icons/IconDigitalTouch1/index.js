export { IconDigitalTouch1 } from "./IconDigitalTouch1";
