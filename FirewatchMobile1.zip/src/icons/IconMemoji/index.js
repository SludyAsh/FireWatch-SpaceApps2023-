export { IconMemoji } from "./IconMemoji";
